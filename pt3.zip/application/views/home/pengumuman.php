<section class="container">
    <div class="row">
        <div class="col-md-12">
            <img width="100%" src="<?= base_url('assets/img/'.$pengumuman['sampul']); ?>" alt="Sampul Pengumuman" class="img-fluid">
            <embed src="<?= base_url('assets/file/'.$pengumuman['berkas']); ?>" width="100%" height="1000px" />
        </div>
    </div>
</section>