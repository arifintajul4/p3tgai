<section class="container">
    <div class="row mt-4">
        <div class="col-md-12">
            <div class="jumbotron">
                <?= $info ?>
            </div>
        </div>
    </div>
</section>